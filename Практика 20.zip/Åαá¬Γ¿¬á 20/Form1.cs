﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика_20
{
    public partial class Form1 : Form
    {
        Random ran = new Random();

        public Form1()
        {
            InitializeComponent();
        }


        private void кругToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            Pen black = new Pen(Color.Black, 3);
            gr.DrawEllipse(black, 400, 100, 150, 150);
        }



        private void лининяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            Pen black = new Pen(Color.Black, 3);
            gr.DrawLine(black, 600, 100, 100, 100);
        }

        private void треугольникToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            Pen black = new Pen(Color.Black, 3);
            Point[] point = { new Point(630, 350), new Point(790, 350), new Point(785, 70) };
            gr.DrawPolygon(black, point);


        }

        private void шестиугольникToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            Pen black = new Pen(Color.Black, 3);
            PointF[] point = { new PointF(100, 100), new PointF(100, 200), new PointF(150, 250), new PointF(200, 200), new PointF(200, 100), new PointF(150, 50) };
            gr.DrawPolygon(black, point);

        }

        private void кругToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SolidBrush aq = new SolidBrush(Color.Aqua);
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            gr.FillEllipse(aq, 400, 100, 150, 150);
        }

        private void квадратToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            Pen black = new Pen(Color.Black, 3);
            gr.DrawRectangle(black, 400, 100, 150, 150);
        }

        private void квадратToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SolidBrush aq = new SolidBrush(Color.Aqua);
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            gr.FillRectangle(aq, 400, 100, 150, 150);
        }

        private void треугольникToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SolidBrush aq = new SolidBrush(Color.Aqua);
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            Point[] point = { new Point(630, 350), new Point(790, 350), new Point(785, 70) };
            gr.FillPolygon(aq, point);
        }

        private void шестиугольникToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            SolidBrush aq = new SolidBrush(Color.Aqua);
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            PointF[] point = { new PointF(100, 100), new PointF(100, 200), new PointF(150, 250), new PointF(200, 200), new PointF(200, 100), new PointF(150, 50) };
            gr.FillPolygon(aq, point);

        }

        private void кругToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void квадратToolStripMenuItem2_Click(object sender, EventArgs e)
        {

            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);

            int x = 300, y = 150, x1 = 200, y1 = 200;
            for (int i = 0; i < 10; i++)
            {
                Pen p = new Pen(Color.FromArgb(255, ran.Next(0, 256), ran.Next(0, 256), ran.Next(0, 226)), 3);
                gr.DrawRectangle(p, x, y, x1, y1);
                x -= 5;
                y -= 5;
                x1 += 10;
                y1 += 10;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void снеговикToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            SolidBrush White = new SolidBrush(Color.White);
            SolidBrush Black = new SolidBrush(Color.Black);
            SolidBrush Orange = new SolidBrush(Color.Orange);
            SolidBrush Gray = new SolidBrush(Color.Gray);
            SolidBrush Green = new SolidBrush(Color.Green);
            SolidBrush Brown = new SolidBrush(Color.Brown);
            Graphics gr = this.CreateGraphics();
            gr.Clear(SystemColors.Control);
            Point[] snowman =
            {
                new Point(435,130),
                new Point(425,150),
                new Point(465,150)
            };
            Point[] ved =
          {
                new Point(435,60),
                new Point(470,100),
                new Point(400,100),
            };
            Point[] nos =
            {
                new Point(430, 140),
                new Point(440, 140),
                new Point(435, 160)
        };
            gr.FillEllipse(White, 400, 100, 75, 75);
            gr.FillEllipse(White, 390, 175, 100, 100);
            gr.FillEllipse(White, 375, 275, 125, 125);
            gr.FillEllipse(Black, 450, 115, 10, 10);
            gr.FillEllipse(Black, 415, 115, 10, 10);
            gr.FillPolygon(Orange, nos);
            gr.FillPolygon(Gray, ved);
            gr.FillRectangle(Brown, 135, 390, 30, 60);
            gr.FillRectangle(Brown, 285, 300, 30, 60);
            gr.FillRectangle(Brown, 645, 350, 30, 60);
            Point[] elk1 =
                {
                new Point(100,400),
                new Point(200, 400),
                new Point(150, 200)
            };
            gr.FillPolygon(Green, elk1);
            Point[] elk2 =
                { new Point(250, 300),
                new Point(350, 300),
                new Point(300, 70)
            };
            gr.FillPolygon(Green, elk2);
            Point[] elk3 =
                { new Point(610, 350),
                new Point(710, 350),
                new Point(660, 70)
            };
            gr.FillPolygon(Green, elk3);

            gr.Dispose();
        }

        private void кругToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Graphics gr = this.CreateGraphics();
            Pen p = new Pen(Color.Purple, 3);

            for (int i = 0; i <= 360; i += 4)
            {
                gr.DrawEllipse(p, i + 360, i - 100, 50, 50);
                Thread.Sleep(50);
                gr.Clear(Color.White);


                for (int j = -100; j <= 360; j += 4)
                {
                    gr.DrawEllipse(p, j + 360, j + 100, 50, 50);
                    Thread.Sleep(50);
                    gr.Clear(Color.White);
                }
            }
            gr.Dispose();
        }

    

       
    }
    }

