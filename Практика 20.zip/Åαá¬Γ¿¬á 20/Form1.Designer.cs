﻿namespace Практика_20
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.фИГУРЫToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кругToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.квадратToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.лининяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.треугольникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.шестиугольникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.зАКРАШЕННЫЕФИГУРЫToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кругToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.квадратToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.треугольникToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.шестиугольникToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.вЛОЖЕННЫЕФИГУРЫToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.квадратToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.снеговикToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.снеговикToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.лЕТАЮЩИЙКРУГToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.кругToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.фИГУРЫToolStripMenuItem,
            this.зАКРАШЕННЫЕФИГУРЫToolStripMenuItem,
            this.вЛОЖЕННЫЕФИГУРЫToolStripMenuItem,
            this.снеговикToolStripMenuItem,
            this.лЕТАЮЩИЙКРУГToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // фИГУРЫToolStripMenuItem
            // 
            this.фИГУРЫToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.фИГУРЫToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.кругToolStripMenuItem,
            this.квадратToolStripMenuItem,
            this.лининяToolStripMenuItem,
            this.треугольникToolStripMenuItem,
            this.шестиугольникToolStripMenuItem});
            this.фИГУРЫToolStripMenuItem.Name = "фИГУРЫToolStripMenuItem";
            this.фИГУРЫToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.фИГУРЫToolStripMenuItem.Text = "ФИГУРЫ";
            // 
            // кругToolStripMenuItem
            // 
            this.кругToolStripMenuItem.Name = "кругToolStripMenuItem";
            this.кругToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.кругToolStripMenuItem.Text = "Круг";
            this.кругToolStripMenuItem.Click += new System.EventHandler(this.кругToolStripMenuItem_Click);
            // 
            // квадратToolStripMenuItem
            // 
            this.квадратToolStripMenuItem.Name = "квадратToolStripMenuItem";
            this.квадратToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.квадратToolStripMenuItem.Text = "Квадрат";
            this.квадратToolStripMenuItem.Click += new System.EventHandler(this.квадратToolStripMenuItem_Click);
            // 
            // лининяToolStripMenuItem
            // 
            this.лининяToolStripMenuItem.Name = "лининяToolStripMenuItem";
            this.лининяToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.лининяToolStripMenuItem.Text = "Лининя";
            this.лининяToolStripMenuItem.Click += new System.EventHandler(this.лининяToolStripMenuItem_Click);
            // 
            // треугольникToolStripMenuItem
            // 
            this.треугольникToolStripMenuItem.Name = "треугольникToolStripMenuItem";
            this.треугольникToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.треугольникToolStripMenuItem.Text = "Треугольник";
            this.треугольникToolStripMenuItem.Click += new System.EventHandler(this.треугольникToolStripMenuItem_Click);
            // 
            // шестиугольникToolStripMenuItem
            // 
            this.шестиугольникToolStripMenuItem.Name = "шестиугольникToolStripMenuItem";
            this.шестиугольникToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.шестиугольникToolStripMenuItem.Text = "Шестиугольник";
            this.шестиугольникToolStripMenuItem.Click += new System.EventHandler(this.шестиугольникToolStripMenuItem_Click);
            // 
            // зАКРАШЕННЫЕФИГУРЫToolStripMenuItem
            // 
            this.зАКРАШЕННЫЕФИГУРЫToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.кругToolStripMenuItem1,
            this.квадратToolStripMenuItem1,
            this.треугольникToolStripMenuItem1,
            this.шестиугольникToolStripMenuItem1});
            this.зАКРАШЕННЫЕФИГУРЫToolStripMenuItem.Name = "зАКРАШЕННЫЕФИГУРЫToolStripMenuItem";
            this.зАКРАШЕННЫЕФИГУРЫToolStripMenuItem.Size = new System.Drawing.Size(156, 20);
            this.зАКРАШЕННЫЕФИГУРЫToolStripMenuItem.Text = "ЗАКРАШЕННЫЕ ФИГУРЫ";
            // 
            // кругToolStripMenuItem1
            // 
            this.кругToolStripMenuItem1.Name = "кругToolStripMenuItem1";
            this.кругToolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.кругToolStripMenuItem1.Text = "Круг";
            this.кругToolStripMenuItem1.Click += new System.EventHandler(this.кругToolStripMenuItem1_Click);
            // 
            // квадратToolStripMenuItem1
            // 
            this.квадратToolStripMenuItem1.Name = "квадратToolStripMenuItem1";
            this.квадратToolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.квадратToolStripMenuItem1.Text = "Квадрат";
            this.квадратToolStripMenuItem1.Click += new System.EventHandler(this.квадратToolStripMenuItem1_Click);
            // 
            // треугольникToolStripMenuItem1
            // 
            this.треугольникToolStripMenuItem1.Name = "треугольникToolStripMenuItem1";
            this.треугольникToolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.треугольникToolStripMenuItem1.Text = "Треугольник";
            this.треугольникToolStripMenuItem1.Click += new System.EventHandler(this.треугольникToolStripMenuItem1_Click);
            // 
            // шестиугольникToolStripMenuItem1
            // 
            this.шестиугольникToolStripMenuItem1.Name = "шестиугольникToolStripMenuItem1";
            this.шестиугольникToolStripMenuItem1.Size = new System.Drawing.Size(160, 22);
            this.шестиугольникToolStripMenuItem1.Text = "Шестиугольник";
            this.шестиугольникToolStripMenuItem1.Click += new System.EventHandler(this.шестиугольникToolStripMenuItem1_Click);
            // 
            // вЛОЖЕННЫЕФИГУРЫToolStripMenuItem
            // 
            this.вЛОЖЕННЫЕФИГУРЫToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.квадратToolStripMenuItem2});
            this.вЛОЖЕННЫЕФИГУРЫToolStripMenuItem.Name = "вЛОЖЕННЫЕФИГУРЫToolStripMenuItem";
            this.вЛОЖЕННЫЕФИГУРЫToolStripMenuItem.Size = new System.Drawing.Size(143, 20);
            this.вЛОЖЕННЫЕФИГУРЫToolStripMenuItem.Text = "ВЛОЖЕННЫЕ ФИГУРЫ";
            // 
            // квадратToolStripMenuItem2
            // 
            this.квадратToolStripMenuItem2.Name = "квадратToolStripMenuItem2";
            this.квадратToolStripMenuItem2.Size = new System.Drawing.Size(117, 22);
            this.квадратToolStripMenuItem2.Text = "Квадрат";
            this.квадратToolStripMenuItem2.Click += new System.EventHandler(this.квадратToolStripMenuItem2_Click);
            // 
            // снеговикToolStripMenuItem
            // 
            this.снеговикToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.снеговикToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.снеговикToolStripMenuItem1});
            this.снеговикToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.снеговикToolStripMenuItem.Name = "снеговикToolStripMenuItem";
            this.снеговикToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.снеговикToolStripMenuItem.Text = "РИСУНКИ";
            // 
            // снеговикToolStripMenuItem1
            // 
            this.снеговикToolStripMenuItem1.BackColor = System.Drawing.SystemColors.Control;
            this.снеговикToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.снеговикToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.снеговикToolStripMenuItem1.Name = "снеговикToolStripMenuItem1";
            this.снеговикToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.снеговикToolStripMenuItem1.Text = "Снеговик";
            this.снеговикToolStripMenuItem1.Click += new System.EventHandler(this.снеговикToolStripMenuItem1_Click);
            // 
            // лЕТАЮЩИЙКРУГToolStripMenuItem
            // 
            this.лЕТАЮЩИЙКРУГToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.кругToolStripMenuItem3});
            this.лЕТАЮЩИЙКРУГToolStripMenuItem.Name = "лЕТАЮЩИЙКРУГToolStripMenuItem";
            this.лЕТАЮЩИЙКРУГToolStripMenuItem.Size = new System.Drawing.Size(136, 20);
            this.лЕТАЮЩИЙКРУГToolStripMenuItem.Text = "ЛЕТАЮЩИЕ ФИГУРЫ";
            // 
            // кругToolStripMenuItem3
            // 
            this.кругToolStripMenuItem3.Name = "кругToolStripMenuItem3";
            this.кругToolStripMenuItem3.Size = new System.Drawing.Size(99, 22);
            this.кругToolStripMenuItem3.Text = "Круг";
            this.кругToolStripMenuItem3.Click += new System.EventHandler(this.кругToolStripMenuItem3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem фИГУРЫToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem кругToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem квадратToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem лининяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem треугольникToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem шестиугольникToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem зАКРАШЕННЫЕФИГУРЫToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem кругToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem квадратToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem треугольникToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem шестиугольникToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem вЛОЖЕННЫЕФИГУРЫToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem квадратToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem лЕТАЮЩИЙКРУГToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem кругToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem снеговикToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem снеговикToolStripMenuItem1;
    }
}

